+RUN main.cpp
+RUN plot_benchmark.py
+SEE THE RESULT IN times.csv & benchmark_plot.png